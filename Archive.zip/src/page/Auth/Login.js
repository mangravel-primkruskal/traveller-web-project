import React, { useState } from 'react';
import TInput from '../../component/TInput';
import TButton from '../../component/TButton';

function Login() {
  const [username, setUsername] = useState('');

  function handleUsernameChange(e) {
    setUsername(e.target.value);
  }

  return (
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
      <div>
        <TInput label="Username" type="text" />
        <TInput label="Password" type="password" />
        <TButton>Login</TButton>
      </div>
    </div>
  );
}

export default Login;
