import React, { useState } from 'react';
import TInput from '../../component/TInput';
import TButton from '../../component/TButton';

function Register() {
  const [username, setUsername] = useState('');

  function handleUsernameChange(e) {
    setUsername(e.target.value);
  }

  return (
  
    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '150vh' }}>
     
     <h1>Register Page</h1>
      <div>
        <TInput label="İsim Soyisim" type="text" />
        <TInput label="Adres" type="text" />
        <TInput label="Şehir" type="text" />
        <TInput label="İlçe" type="text" />
        <TInput label="Mekan Kategori" type="text" />
        <TInput label="Mekan İsmi" type="text" />
        <TInput label="Mekan Ses Düzeyi" type="text" />
        <TInput label="Mekan Müşteri Kategorisi" type="text" />
        <TInput label="Mekan Ürün Kategorisi" type="text" />
        <TInput label="Kullanıcı Adı" type="text" />
        <TInput label="Password" type="password" />

        <TButton>Register</TButton>
      </div>
    </div>
  );
}

export default Register;
