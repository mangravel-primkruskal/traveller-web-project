import React from 'react';

function Home() {
  return (
    <div>
      <h1>Hoş Geldiniz</h1>
      <p>Bu, yeni ana sayfanızdır!</p>
    </div>
  );
}

export default Home;
